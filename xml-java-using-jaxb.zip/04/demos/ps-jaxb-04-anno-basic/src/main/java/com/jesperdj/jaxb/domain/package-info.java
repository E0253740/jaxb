@XmlAccessorType(XmlAccessType.FIELD)
package com.jesperdj.jaxb.domain;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
