package com.jesperdj.jaxb.domain;

public enum Loyalty {
    BRONZE, SILVER, GOLD
}
