@XmlAccessorType(XmlAccessType.FIELD)
@XmlSchema(namespace = "http://www.jesperdj.com/ps-jaxb", elementFormDefault = XmlNsForm.QUALIFIED)
package com.jesperdj.jaxb.domain;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;
