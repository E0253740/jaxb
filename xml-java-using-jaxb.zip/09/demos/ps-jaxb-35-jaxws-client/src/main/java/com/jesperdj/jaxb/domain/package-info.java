@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.jesperdj.com/ps-jaxb", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.jesperdj.jaxb.domain;
